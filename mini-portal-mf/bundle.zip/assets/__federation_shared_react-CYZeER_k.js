import{i as f}from"./index-Bdg6H79-.js";export{f as default};
//# sourceMappingURL=__federation_shared_react-CYZeER_k.js.map
