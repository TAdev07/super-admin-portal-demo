import{i as f}from"./index-_45WSzdo.js";export{f as default};
//# sourceMappingURL=__federation_shared_react-dom-V__t3mgJ.js.map
